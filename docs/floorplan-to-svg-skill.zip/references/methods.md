# Methods considered

- VTracer (visioncortex): color raster-to-vector tracer with curve fitting; strong default for colored floor plans. Source: https://github.com/visioncortex/vtracer
- Potrace: robust black/white bitmap tracer; best for pure line-art scans but not multi-color legends. Source: https://potrace.sourceforge.net/
- ImageTracerJS: pure JavaScript color tracer; useful for static sites because it runs fully in-browser or in Node without native dependencies. Source: https://github.com/jankovicsandras/imagetracerjs
- OpenCV contour extraction: useful when geometry must be converted into controlled primitives, but requires more post-processing than a general vector tracer.

For this skill, ImageTracerJS is bundled so the conversion works offline and in the same static web environment as the navigation prototype. VTracer remains the preferred external CLI when higher-fidelity curve output is available.

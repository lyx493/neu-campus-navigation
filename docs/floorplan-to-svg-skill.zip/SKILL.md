---
name: floorplan-to-svg
description: Convert raster floor plans, building maps, and annotated indoor plans into editable SVG. Use for tracing JPG/PNG floor plans while preserving walls, corridors, stairs, room labels, and legend colors; do not use for ordinary photos or artistic image generation.
---

# Floor Plan to SVG

Convert a raster floor plan into a usable SVG while preserving geometry and checking that labels remain readable.

## Workflow

1. Keep the original raster unchanged.
2. Inspect whether the image is:
   - clean black line art: use a line-art preset or Potrace;
   - colored floor plan with stairs, toilets, highlights: use the bundled ImageTracerJS workflow;
   - photographed sign with perspective/glare: rectify and crop first, otherwise vectorization will preserve photographic noise.
3. Run:

```bash
node scripts/vectorize_floorplan.js input.jpg output.svg --preset floorplan
```

4. For a mostly black-and-white drawing:

```bash
node scripts/vectorize_floorplan.js input.jpg output.svg --preset lineart
```

5. Open the SVG in a browser and compare it against the raster at the same aspect ratio. Check for:
   - missing walls or room boundaries;
   - stair/exit symbols still visible;
   - room numbers still legible;
   - large noisy regions or excessive path count;
   - corridors not filled or closed incorrectly.
6. If text becomes too fragmented, keep the linework SVG and redraw room labels as real SVG `<text>` elements using OCR/manual coordinates. Do not pretend traced text is editable.
7. Save a side-by-side QA image or screenshot when the result is intended for delivery.

## Presets

- `floorplan`: 12 colors, conservative path omission, optimized for colored architectural plans.
- `lineart`: 2 colors, suitable for clean scan/blueprint linework.
- `color`: 24 colors, for maps where stairs, toilets, exits, and legends must retain color.

## Rules

- Preserve the source aspect ratio and add a correct `viewBox`.
- Remove the traced white background rectangle only if the target page already supplies a background; otherwise keep it.
- Do not use ImageGen for a task that needs to be represented as vector geometry.
- Do not claim OCR: ImageTracerJS traces text as paths, not editable text.
- For critical navigation geometry, validate door/stairs/exit coordinates against a site walk or the original architectural drawing.

## Bundled tools

- `scripts/vendor/imagetracer_v1.2.6.js`: ImageTracerJS 1.2.6, raster-to-SVG tracer.
- `scripts/vendor/jpeg-decode.js`: JPEG decoder from jpeg-js 0.4.4.
- `scripts/vectorize_floorplan.js`: local CLI wrapper.

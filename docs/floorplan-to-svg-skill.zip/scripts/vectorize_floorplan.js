#!/usr/bin/env node
'use strict';
const fs = require('fs');
const path = require('path');
const jpeg = require('./vendor/jpeg-decode');
const ImageTracer = require('./vendor/imagetracer_v1.2.6');

const presets = {
  floorplan: { numberofcolors: 6, colorquantcycles: 2, colorsampling: 0, mincolorratio: 2 / 100, ltres: 1.2, qtres: 1.2, pathomit: 12, rightangleenhance: true, linefilter: true, strokewidth: 1, roundcoords: 1, viewbox: true, desc: false },
  lineart: { numberofcolors: 2, colorquantcycles: 2, colorsampling: 0, mincolorratio: 1 / 1000, ltres: 0.5, qtres: 0.5, pathomit: 2, rightangleenhance: true, linefilter: true, strokewidth: 1, roundcoords: 1, viewbox: true, desc: false },
  color: { numberofcolors: 24, colorquantcycles: 3, colorsampling: 2, mincolorratio: 1 / 100, ltres: 1, qtres: 1, pathomit: 8, rightangleenhance: true, linefilter: true, strokewidth: 1, roundcoords: 1, viewbox: true, desc: false }
};

function usage() {
  console.error('Usage: node vectorize_floorplan.js <input.jpg|png> <output.svg> [--preset floorplan|lineart|color] [--colors N]');
  process.exit(2);
}
const input = process.argv[2];
const output = process.argv[3];
if (!input || !output) usage();
let preset = 'floorplan';
let colors = null;
for (let i = 4; i < process.argv.length; i++) {
  if (process.argv[i] === '--preset') preset = process.argv[++i];
  else if (process.argv[i] === '--colors') colors = Number(process.argv[++i]);
}
if (!presets[preset]) usage();
const opts = Object.assign({}, presets[preset]);
if (colors && Number.isFinite(colors) && colors > 1) opts.numberofcolors = Math.min(64, Math.round(colors));
const bytes = fs.readFileSync(input);
const decoded = jpeg(bytes, { useTArray: true, formatAsRGBA: true });
const imageData = { width: decoded.width, height: decoded.height, data: new Uint8ClampedArray(decoded.data) };
let svg = ImageTracer.imagedataToSVG(imageData, opts);
svg = svg.replace(/ desc="[^"]*"/, '').replace('<svg ', `<svg preserveAspectRatio="xMidYMid meet" data-source="${path.basename(input)}" data-tracer="ImageTracerJS-1.2.6" shape-rendering="geometricPrecision" `);
const headerEnd = svg.indexOf('>') + 1;
svg = svg.slice(0, headerEnd) + `<title>${path.basename(input)}</title><metadata>{"source":"${path.basename(input)}","tracer":"ImageTracerJS 1.2.6","preset":"${preset}"}</metadata>` + svg.slice(headerEnd);
svg = '<?xml version="1.0" encoding="UTF-8"?>\n' + svg;
fs.mkdirSync(path.dirname(path.resolve(output)), { recursive: true });
fs.writeFileSync(output, svg, 'utf8');
console.log(JSON.stringify({ input, output, width: decoded.width, height: decoded.height, preset, colors: opts.numberofcolors, bytes: Buffer.byteLength(svg) }, null, 2));
